import type { Request, Response } from 'express';
import { Bot, InlineKeyboard, Keyboard, webhookCallback } from 'grammy';
import type { BotRuntimeStatus, Order, Product, ProductCategory } from '../types.ts';
import { store } from './store.ts';

const FALLBACK_TOKEN = '8889525969:AAHzlNVi_PGRGw-UnDWpLQwJVL5fD7RjZno';

function getBotToken(): string {
  return (process.env.TELEGRAM_BOT_TOKEN || FALLBACK_TOKEN).trim();
}

function formatUzs(amount: number): string {
  return `${amount.toLocaleString('uz-UZ').replace(/,/g, ' ')} so‘m`;
}

function categoryLabel(category: ProductCategory): string {
  switch (category) {
    case 'stars':
      return 'Telegram Stars';
    case 'premium':
      return 'Telegram Premium';
    case 'gifts':
      return 'Telegram Hadya';
    case 'boost':
      return 'Kanal Boost';
  }
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

interface UserSession {
  step: 'idle' | 'awaiting_target_username' | 'awaiting_receipt' | 'admin_broadcast' | 'admin_reply_user';
  selectedProductId?: string;
  targetUsername?: string;
  replyToUserId?: number;
}

const sessions = new Map<number, UserSession>();

let botInstance: Bot | null = null;
let watchdogTimer: ReturnType<typeof setInterval> | null = null;
let reportTimer: ReturnType<typeof setInterval> | null = null;
let isStarting = false;
let manualStop = false;

const runtimeStatus: BotRuntimeStatus = {
  running: false,
  pollingActive: false,
  connectionMode: 'polling',
  webhookUrl: null,
  pendingUpdatesCount: 0,
  botId: null,
  botUsername: null,
  botFirstName: null,
  startedAt: null,
  uptimeSeconds: 0,
  lastHeartbeatAt: null,
  lastError: null,
  reconnectCount: 0,
};

function getMainKeyboard(isAdmin: boolean) {
  const kb = new Keyboard()
    .text('⭐ Telegram Stars')
    .text('💎 Telegram Premium')
    .row()
    .text('🎁 Boshqa xizmatlar')
    .text('📦 Buyurtmalarim')
    .row()
    .text('💰 Balans / Referal')
    .text('❓ Savol-javob (FAQ)')
    .row()
    .text('☎️ Yordam / Aloqa');

  if (isAdmin) {
    kb.text('🛠 Admin Panel');
  }
  return kb.resized();
}

function buildFaqListKeyboard(): InlineKeyboard {
  const faqs = store.getFaqs(true);
  const kb = new InlineKeyboard();
  faqs.forEach((faq, idx) => {
    const label = faq.question.length > 52 ? `${faq.question.slice(0, 49)}...` : faq.question;
    kb.text(`${idx + 1}. ${label}`, `faq:view:${faq.id}`).row();
  });
  kb.text('⬅️ Bosh menyu', 'nav:home');
  return kb;
}

function buildCategoryKeyboard(category: ProductCategory): InlineKeyboard {
  const products = store.getProductsByCategory(category, true);
  const kb = new InlineKeyboard();
  for (const product of products) {
    const discount = Math.max(0, product.marketPrice - product.ourPrice);
    const label =
      discount > 0
        ? `${product.title} — ${formatUzs(product.ourPrice)} (-${formatUzs(discount)})`
        : `${product.title} — ${formatUzs(product.ourPrice)}`;
    kb.text(label, `buy:${product.id}`).row();
  }
  kb.text('⬅️ Bosh menyu', 'nav:home');
  return kb;
}

function buildAdminKeyboard(): InlineKeyboard {
  const settings = store.getSettings();
  const appUrl = process.env.APP_URL;
  const kb = new InlineKeyboard()
    .text('📊 Statistika', 'admin:stats')
    .text('⏳ Kutilayotgan buyurtmalar', 'admin:pending')
    .row()
    .text('💰 Narxlar ro‘yxati', 'admin:prices')
    .text('📢 E‘lon yuborish', 'admin:broadcast')
    .row()
    .text(
      settings.maintenanceMode ? '🟢 Do‘konni yoqish' : '🔴 Texnik tanaffus',
      'admin:toggle_maintenance'
    );

  if (appUrl && appUrl.startsWith('http')) {
    kb.row().url('🌐 Web Admin Panelni ochish', appUrl);
  }
  return kb;
}

function createBot(token: string): Bot {
  const bot = new Bot(token);

  bot.catch((err) => {
    const message = err.error instanceof Error ? err.error.message : String(err.error);
    console.error('[TelegramBot] Update handler error:', message);
    runtimeStatus.lastError = message;
  });

  // Guard middleware: register/update user & block banned users
  bot.use(async (ctx, next) => {
    if (!ctx.from) return next();
    let referredBy: number | null = null;
    if (ctx.message?.text?.startsWith('/start ')) {
      const payload = ctx.message.text.slice(7).trim();
      if (payload.startsWith('ref_')) {
        const refId = Number(payload.slice(4));
        if (!Number.isNaN(refId) && refId > 0) {
          referredBy = refId;
        }
      }
    }

    const { user } = store.upsertUser({
      telegramId: ctx.from.id,
      username: ctx.from.username ?? null,
      firstName: ctx.from.first_name || 'Foydalanuvchi',
      lastName: ctx.from.last_name ?? null,
      referredBy,
    });

    if (user.isBanned && !store.isAdmin(ctx.from.id)) {
      await ctx.reply('⛔ Sizning hisobingiz administrator tomonidan cheklangan.');
      return;
    }

    const settings = store.getSettings();
    if (
      settings.maintenanceMode &&
      !store.isAdmin(ctx.from.id) &&
      ctx.message?.text !== '/start'
    ) {
      await ctx.reply(
        '🛠 Do‘konda qisqa texnik ishlar olib borilmoqda. Tez orada qaytamiz!\n\nAloqa: ' +
          settings.supportUsername
      );
      return;
    }

    await next();
  });

  bot.command('start', async (ctx) => {
    if (!ctx.from) return;
    sessions.set(ctx.from.id, { step: 'idle' });
    const settings = store.getSettings();
    const isAdmin = store.isAdmin(ctx.from.id);

    const starsExample = store.getProductById('stars-100');
    const exampleLine = starsExample
      ? `\n\n🔥 <b>Misol:</b> ${escapeHtml(starsExample.title)} bozorda <s>${formatUzs(
          starsExample.marketPrice
        )}</s> — bizda atigi <b>${formatUzs(starsExample.ourPrice)}</b>!`
      : '';

    await ctx.reply(
      `👋 Assalomu alaykum, <b>${escapeHtml(ctx.from.first_name)}</b>!\n\n` +
        `<b>${escapeHtml(settings.shopName)}</b> — ${escapeHtml(settings.welcomeMessage)}` +
        exampleLine +
        `\n\nQuyidagi bo‘limlardan birini tanlang:`,
      {
        parse_mode: 'HTML',
        reply_markup: getMainKeyboard(isAdmin),
      }
    );
  });

  bot.command('admin', async (ctx) => {
    if (!ctx.from || !store.isAdmin(ctx.from.id)) {
      await ctx.reply('⛔ Bu buyruq faqat administrator uchun.');
      return;
    }
    await sendAdminHome(ctx.from.id);
  });

  async function sendAdminHome(chatId: number) {
    const summary = store.getSummary();
    const settings = store.getSettings();
    const text =
      `🛠 <b>Admin Boshqaruv Paneli</b>\n\n` +
      `👥 Foydalanuvchilar: <b>${summary.totalUsersCount}</b>\n` +
      `⏳ Kutilayotgan buyurtmalar: <b>${summary.pendingOrdersCount}</b>\n` +
      `✅ Bajarilgan buyurtmalar: <b>${summary.completedOrdersCount}</b>\n` +
      `💰 Jami tushum: <b>${formatUzs(summary.totalRevenue)}</b>\n` +
      `🏷 Mijozlar tejagan summa: <b>${formatUzs(summary.totalSavingsForUsers)}</b>\n` +
      `🏪 Holat: <b>${settings.maintenanceMode ? '🔴 Texnik tanaffus' : '🟢 Ochiq (24/7)'}</b>`;

    await bot.api.sendMessage(chatId, text, {
      parse_mode: 'HTML',
      reply_markup: buildAdminKeyboard(),
    });
  }

  // Category & menu triggers
  bot.hears('⭐ Telegram Stars', async (ctx) => {
    if (!ctx.from) return;
    sessions.set(ctx.from.id, { step: 'idle' });
    const products = store.getProductsByCategory('stars', true);
    if (products.length === 0) {
      await ctx.reply('Hozircha Stars paketlari mavjud emas.');
      return;
    }
    await ctx.reply(
      `⭐ <b>Telegram Stars paketlari</b>\n\n` +
        `Bozor narxidan arzonlashtirilgan tariflar. Kerakli miqdorni tanlang:`,
      {
        parse_mode: 'HTML',
        reply_markup: buildCategoryKeyboard('stars'),
      }
    );
  });

  bot.hears('💎 Telegram Premium', async (ctx) => {
    if (!ctx.from) return;
    sessions.set(ctx.from.id, { step: 'idle' });
    const products = store.getProductsByCategory('premium', true);
    if (products.length === 0) {
      await ctx.reply('Hozircha Premium tariflari mavjud emas.');
      return;
    }
    await ctx.reply(
      `💎 <b>Telegram Premium obunalari</b>\n\n` +
        `Bozor narxidan arzon va kafolatlangan rasmiy obuna. Muddatni tanlang:`,
      {
        parse_mode: 'HTML',
        reply_markup: buildCategoryKeyboard('premium'),
      }
    );
  });

  bot.hears('🎁 Boshqa xizmatlar', async (ctx) => {
    if (!ctx.from) return;
    sessions.set(ctx.from.id, { step: 'idle' });
    const gifts = store.getProductsByCategory('gifts', true);
    const boosts = store.getProductsByCategory('boost', true);
    const kb = new InlineKeyboard();
    for (const product of [...gifts, ...boosts]) {
      kb.text(`${product.title} — ${formatUzs(product.ourPrice)}`, `buy:${product.id}`).row();
    }
    kb.text('⬅️ Bosh menyu', 'nav:home');

    if (gifts.length === 0 && boosts.length === 0) {
      await ctx.reply('Hozircha qo‘shimcha xizmatlar mavjud emas.');
      return;
    }
    await ctx.reply(
      `🎁 <b>Telegram Hadya va Kanal Boost xizmatlari</b>\n\nKerakli xizmatni tanlang:`,
      {
        parse_mode: 'HTML',
        reply_markup: kb,
      }
    );
  });

  bot.hears('📦 Buyurtmalarim', async (ctx) => {
    if (!ctx.from) return;
    const orders = store.getOrdersByUser(ctx.from.id).slice(0, 10);
    if (orders.length === 0) {
      await ctx.reply('Sizda hali buyurtmalar yo‘q. ⭐ Telegram Stars yoki 💎 Premium bo‘limidan xarid qilishingiz mumkin.');
      return;
    }
    const statusMap: Record<Order['status'], string> = {
      awaiting_payment: '💳 To‘lov kutilmoqda',
      pending_review: '⏳ Tekshirilmoqda',
      completed: '✅ Bajarildi',
      cancelled: '❌ Bekor qilindi',
    };

    const lines = orders.map(
      (o) =>
        `• <b>${o.id}</b> — ${escapeHtml(o.productTitle)}\n` +
        `  Qabul qiluvchi: <code>${escapeHtml(o.targetUsername)}</code> | ${formatUzs(o.paidAmount)}\n` +
        `  Holat: ${statusMap[o.status]}`
    );

    await ctx.reply(`📦 <b>So‘nggi buyurtmalaringiz:</b>\n\n${lines.join('\n\n')}`, {
      parse_mode: 'HTML',
    });
  });

  bot.hears('💰 Balans / Referal', async (ctx) => {
    if (!ctx.from) return;
    const user = store.getUser(ctx.from.id);
    const settings = store.getSettings();
    const botUsername = runtimeStatus.botUsername || 'bot';
    const refLink = `https://t.me/${botUsername}?start=ref_${ctx.from.id}`;

    await ctx.reply(
      `💰 <b>Shaxsiy hisobingiz</b>\n\n` +
        `🆔 ID: <code>${ctx.from.id}</code>\n` +
        `💵 Bonus balans: <b>${formatUzs(user?.balance ?? 0)}</b>\n` +
        `🛒 Jami xaridlar: <b>${user?.ordersCount ?? 0} ta</b> (${formatUzs(user?.totalSpent ?? 0)})\n\n` +
        `👥 <b>Referal dasturi (${settings.referralBonusPercent}% bonus):</b>\n` +
        `Do‘stlaringizni taklif qiling va ularning har bir xarididan <b>${settings.referralBonusPercent}%</b> bonus oling:\n` +
        `<code>${refLink}</code>`,
      { parse_mode: 'HTML' }
    );
  });

  bot.command('faq', async (ctx) => {
    const faqs = store.getFaqs(true);
    if (faqs.length === 0) {
      await ctx.reply('Hozircha savol-javoblar ro‘yxati bo‘sh.');
      return;
    }
    await ctx.reply(
      `❓ <b>Tez-tez so‘raladigan savollar (FAQ)</b>\n\n` +
        `Kerakli savolni tanlang — batafsil javob darhol chiqadi:`,
      {
        parse_mode: 'HTML',
        reply_markup: buildFaqListKeyboard(),
      }
    );
  });

  bot.hears('❓ Savol-javob (FAQ)', async (ctx) => {
    const faqs = store.getFaqs(true);
    if (faqs.length === 0) {
      await ctx.reply('Hozircha savol-javoblar ro‘yxati bo‘sh.');
      return;
    }
    await ctx.reply(
      `❓ <b>Tez-tez so‘raladigan savollar (FAQ)</b>\n\n` +
        `Kerakli savolni tanlang — batafsil javob darhol chiqadi:`,
      {
        parse_mode: 'HTML',
        reply_markup: buildFaqListKeyboard(),
      }
    );
  });

  bot.hears('☎️ Yordam / Aloqa', async (ctx) => {
    const settings = store.getSettings();
    const kb = new InlineKeyboard().text('❓ Ko‘p beriladigan savollar (FAQ)', 'faq:list');
    await ctx.reply(
      `☎️ <b>Qo‘llab-quvvatlash xizmati</b>\n\n` +
        `Savollar, hamkorlik yoki katta hajmdagi buyurtmalar uchun operatorga murojaat qiling:\n` +
        `👤 Operator: ${escapeHtml(settings.supportUsername)}\n` +
        `⏰ Ish tartibi: <b>24/7 uzluksiz</b>`,
      {
        parse_mode: 'HTML',
        reply_markup: kb,
      }
    );
  });

  bot.hears('🛠 Admin Panel', async (ctx) => {
    if (!ctx.from || !store.isAdmin(ctx.from.id)) return;
    sessions.set(ctx.from.id, { step: 'idle' });
    await sendAdminHome(ctx.from.id);
  });

  // Callback queries
  bot.on('callback_query:data', async (ctx) => {
    const data = ctx.callbackQuery.data;
    const userId = ctx.from.id;

    if (data === 'nav:home') {
      sessions.set(userId, { step: 'idle' });
      await ctx.answerCallbackQuery();
      await ctx.reply('Asosiy menyu:', {
        reply_markup: getMainKeyboard(store.isAdmin(userId)),
      });
      return;
    }

    if (data === 'faq:list') {
      const faqs = store.getFaqs(true);
      await ctx.answerCallbackQuery();
      const text =
        faqs.length === 0
          ? 'Hozircha savol-javoblar ro‘yxati bo‘sh.'
          : `❓ <b>Tez-tez so‘raladigan savollar (FAQ)</b>\n\nKerakli savolni tanlang — batafsil javob darhol chiqadi:`;
      const replyMarkup = faqs.length > 0 ? buildFaqListKeyboard() : undefined;
      try {
        await ctx.editMessageText(text, {
          parse_mode: 'HTML',
          reply_markup: replyMarkup,
        });
      } catch {
        await ctx.reply(text, {
          parse_mode: 'HTML',
          reply_markup: replyMarkup,
        });
      }
      return;
    }

    if (data.startsWith('faq:view:')) {
      const faqId = data.slice('faq:view:'.length);
      const faq = store.getFaqById(faqId);
      if (!faq || !faq.active) {
        await ctx.answerCallbackQuery({ text: 'Bu savol topilmadi.', show_alert: true });
        return;
      }
      await ctx.answerCallbackQuery();
      const settings = store.getSettings();
      const kb = new InlineKeyboard()
        .text('⬅️ Barcha savollar', 'faq:list')
        .text('🏠 Bosh menyu', 'nav:home');
      const text =
        `❓ <b>${escapeHtml(faq.question)}</b>\n\n` +
        `💡 ${escapeHtml(faq.answer)}\n\n` +
        `☎️ Qo‘shimcha savol bo‘lsa: ${escapeHtml(settings.supportUsername)}`;
      try {
        await ctx.editMessageText(text, {
          parse_mode: 'HTML',
          reply_markup: kb,
        });
      } catch {
        await ctx.reply(text, {
          parse_mode: 'HTML',
          reply_markup: kb,
        });
      }
      return;
    }

    if (data.startsWith('buy:')) {
      const productId = data.slice(4);
      const product = store.getProductById(productId);
      if (!product || !product.active) {
        await ctx.answerCallbackQuery({ text: 'Bu mahsulot hozir mavjud emas.', show_alert: true });
        return;
      }

      sessions.set(userId, {
        step: 'awaiting_target_username',
        selectedProductId: product.id,
      });

      const savings = Math.max(0, product.marketPrice - product.ourPrice);
      const kb = new InlineKeyboard();
      if (ctx.from.username) {
        kb.text(`👤 O‘zimga (@${ctx.from.username})`, `target_self:${product.id}`).row();
      }
      kb.text('❌ Bekor qilish', 'order_cancel_flow');

      await ctx.answerCallbackQuery();
      await ctx.reply(
        `🛒 <b>Tanlangan xizmat:</b> ${escapeHtml(product.title)}\n` +
          `🏷 Bozor narxi: <s>${formatUzs(product.marketPrice)}</s>\n` +
          `✅ Bizning narx: <b>${formatUzs(product.ourPrice)}</b>` +
          (savings > 0 ? ` (Tejaysiz: <b>${formatUzs(savings)}</b>)` : '') +
          `\n\n📩 Xizmat yuborilishi kerak bo‘lgan Telegram <b>@username</b>ni yozib yuboring` +
          (product.category === 'boost' ? ` (yoki kanal havolasini)` : '') +
          `:`,
        {
          parse_mode: 'HTML',
          reply_markup: kb,
        }
      );
      return;
    }

    if (data.startsWith('target_self:')) {
      const productId = data.slice(12);
      const product = store.getProductById(productId);
      if (!product || !product.active) {
        await ctx.answerCallbackQuery({ text: 'Mahsulot topilmadi.', show_alert: true });
        return;
      }
      const target = ctx.from.username ? `@${ctx.from.username}` : `ID:${userId}`;
      await ctx.answerCallbackQuery();
      await promptPaymentStep(ctx, userId, product, target);
      return;
    }

    if (data === 'order_cancel_flow') {
      sessions.set(userId, { step: 'idle' });
      await ctx.answerCallbackQuery({ text: 'Buyurtma bekor qilindi.' });
      await ctx.reply('❌ Buyurtma jarayoni bekor qilindi. Boshqa xizmat tanlashingiz mumkin.', {
        reply_markup: getMainKeyboard(store.isAdmin(userId)),
      });
      return;
    }

    // Admin callbacks
    if (data.startsWith('admin:') || data.startsWith('ord_approve:') || data.startsWith('ord_reject:')) {
      if (!store.isAdmin(userId)) {
        await ctx.answerCallbackQuery({ text: 'Sizda admin huquqi yo‘q.', show_alert: true });
        return;
      }

      if (data === 'admin:stats') {
        await ctx.answerCallbackQuery();
        await sendAdminHome(userId);
        return;
      }

      if (data === 'admin:pending') {
        await ctx.answerCallbackQuery();
        const pending = store.getOrders('pending_review');
        if (pending.length === 0) {
          await ctx.reply('✅ Hozircha kutilayotgan buyurtmalar yo‘q.');
          return;
        }
        for (const order of pending.slice(0, 10)) {
          const kb = new InlineKeyboard()
            .text('✅ Tasdiqlash', `ord_approve:${order.id}`)
            .text('❌ Bekor qilish', `ord_reject:${order.id}`);
          const caption =
            `⏳ <b>Buyurtma ${order.id}</b>\n` +
            `📦 Mahsulot: <b>${escapeHtml(order.productTitle)}</b>\n` +
            `👤 Mijoz: ${escapeHtml(order.firstName)} (${order.username ? `@${order.username}` : order.userId})\n` +
            `🎯 Qabul qiluvchi: <code>${escapeHtml(order.targetUsername)}</code>\n` +
            `💵 Summa: <b>${formatUzs(order.paidAmount)}</b>`;

          if (order.receiptFileId) {
            try {
              await bot.api.sendPhoto(userId, order.receiptFileId, {
                caption,
                parse_mode: 'HTML',
                reply_markup: kb,
              });
              continue;
            } catch {
              // fallback to text if file_id failed
            }
          }
          await ctx.reply(caption, { parse_mode: 'HTML', reply_markup: kb });
        }
        return;
      }

      if (data === 'admin:prices') {
        await ctx.answerCallbackQuery();
        const products = store.getProducts(false);
        const lines = products.map(
          (p) =>
            `${p.active ? '🟢' : '⚪'} <b>${escapeHtml(p.title)}</b>\n` +
            `   Bozorda: <s>${formatUzs(p.marketPrice)}</s> → Bizda: <b>${formatUzs(p.ourPrice)}</b>`
        );
        await ctx.reply(
          `💰 <b>Joriy narxlar ro‘yxati:</b>\n\n${lines.join('\n')}\n\n` +
            `<i>Narxlarni Web Admin Panel orqali bir zumda tahrirlashingiz mumkin.</i>`,
          { parse_mode: 'HTML' }
        );
        return;
      }

      if (data === 'admin:broadcast') {
        sessions.set(userId, { step: 'admin_broadcast' });
        await ctx.answerCallbackQuery();
        await ctx.reply(
          '📢 Barcha bot foydalanuvchilariga yuboriladigan xabar matnini yozing.\n\nBekor qilish uchun /cancel yozing.'
        );
        return;
      }

      if (data === 'admin:toggle_maintenance') {
        const current = store.getSettings().maintenanceMode;
        store.updateSettings({ maintenanceMode: !current });
        await ctx.answerCallbackQuery({
          text: !current ? 'Texnik tanaffus yoqildi.' : 'Do‘kon ochildi!',
        });
        await sendAdminHome(userId);
        return;
      }

      if (data.startsWith('ord_approve:')) {
        const orderId = data.slice('ord_approve:'.length);
        const result = store.updateOrderStatus(orderId, 'completed', userId, 'Admin tomonidan tasdiqlandi');
        if (!result) {
          await ctx.answerCallbackQuery({ text: 'Buyurtma topilmadi.', show_alert: true });
          return;
        }
        await ctx.answerCallbackQuery({ text: `${orderId} bajarildi!` });
        await notifyUserOrderUpdate(result.order);
        await ctx.reply(`✅ Buyurtma <b>${orderId}</b> muvaffaqiyatli bajarildi va mijozga xabar yuborildi.`, {
          parse_mode: 'HTML',
        });
        return;
      }

      if (data.startsWith('ord_reject:')) {
        const orderId = data.slice('ord_reject:'.length);
        const result = store.updateOrderStatus(orderId, 'cancelled', userId, 'To‘lov tasdiqlanmadi');
        if (!result) {
          await ctx.answerCallbackQuery({ text: 'Buyurtma topilmadi.', show_alert: true });
          return;
        }
        await ctx.answerCallbackQuery({ text: `${orderId} bekor qilindi.` });
        await notifyUserOrderUpdate(result.order);
        await ctx.reply(`❌ Buyurtma <b>${orderId}</b> bekor qilindi va mijozga xabar berildi.`, {
          parse_mode: 'HTML',
        });
        return;
      }
    }
  });

  async function promptPaymentStep(
    ctx: { reply: (text: string, other?: Record<string, unknown>) => Promise<unknown> },
    userId: number,
    product: Product,
    targetUsername: string
  ) {
    const settings = store.getSettings();
    sessions.set(userId, {
      step: 'awaiting_receipt',
      selectedProductId: product.id,
      targetUsername,
    });

    const kb = new InlineKeyboard().text('❌ Bekor qilish', 'order_cancel_flow');

    await ctx.reply(
      `💳 <b>To‘lov ma’lumotlari</b>\n\n` +
        `📦 Xizmat: <b>${escapeHtml(product.title)}</b>\n` +
        `🎯 Qabul qiluvchi: <code>${escapeHtml(targetUsername)}</code>\n` +
        `💵 To‘lov summasi: <b>${formatUzs(product.ourPrice)}</b>\n\n` +
        `💳 Karta raqami: <code>${escapeHtml(settings.cardNumber)}</code>\n` +
        `👤 Karta egasi: <b>${escapeHtml(settings.cardHolder)}</b>\n\n` +
        `📌 ${escapeHtml(settings.paymentNote)}\n\n` +
        `📸 <b>To‘lov chekini (rasm / skrinshot) shu yerga yuboring:</b>`,
      {
        parse_mode: 'HTML',
        reply_markup: kb,
      }
    );
  }

  bot.command('cancel', async (ctx) => {
    if (!ctx.from) return;
    sessions.set(ctx.from.id, { step: 'idle' });
    await ctx.reply('Amal bekor qilindi.', {
      reply_markup: getMainKeyboard(store.isAdmin(ctx.from.id)),
    });
  });

  // Handle photos (receipts)
  bot.on('message:photo', async (ctx) => {
    if (!ctx.from) return;
    const session = sessions.get(ctx.from.id);
    if (!session || session.step !== 'awaiting_receipt' || !session.selectedProductId) {
      return;
    }

    const product = store.getProductById(session.selectedProductId);
    if (!product) {
      sessions.set(ctx.from.id, { step: 'idle' });
      await ctx.reply('Xatolik: tanlangan mahsulot topilmadi.');
      return;
    }

    const photos = ctx.message.photo;
    const largestPhoto = photos[photos.length - 1];
    const order = store.createOrder({
      userId: ctx.from.id,
      username: ctx.from.username ?? null,
      firstName: ctx.from.first_name || 'Mijoz',
      product,
      targetUsername: session.targetUsername || `@${ctx.from.username || ctx.from.id}`,
      receiptFileId: largestPhoto.file_id,
      receiptCaption: ctx.message.caption ?? null,
      status: 'pending_review',
    });

    sessions.set(ctx.from.id, { step: 'idle' });

    await ctx.reply(
      `✅ <b>Chek qabul qilindi!</b>\n\n` +
        `🆔 Buyurtma raqami: <b>${order.id}</b>\n` +
        `📦 Xizmat: <b>${escapeHtml(order.productTitle)}</b>\n` +
        `🎯 Qabul qiluvchi: <code>${escapeHtml(order.targetUsername)}</code>\n` +
        `💵 Summa: <b>${formatUzs(order.paidAmount)}</b>\n\n` +
        `⏳ Admin chekni tekshirishi bilan xizmat yuboriladi va sizga xabar keladi.`,
      {
        parse_mode: 'HTML',
        reply_markup: getMainKeyboard(store.isAdmin(ctx.from.id)),
      }
    );

    // Notify all admins immediately in Telegram
    await notifyAdminsNewOrder(order);
  });

  // Handle text inputs for active session steps
  bot.on('message:text', async (ctx) => {
    if (!ctx.from) return;
    const text = ctx.message.text.trim();
    if (text.startsWith('/')) return;

    const session = sessions.get(ctx.from.id);
    if (!session || session.step === 'idle') return;

    if (session.step === 'awaiting_target_username' && session.selectedProductId) {
      const product = store.getProductById(session.selectedProductId);
      if (!product) {
        sessions.set(ctx.from.id, { step: 'idle' });
        await ctx.reply('Mahsulot topilmadi.');
        return;
      }
      const normalized =
        text.startsWith('@') || text.startsWith('http') ? text : `@${text}`;
      await promptPaymentStep(ctx, ctx.from.id, product, normalized);
      return;
    }

    if (session.step === 'awaiting_receipt') {
      await ctx.reply('📸 Iltimos, to‘lov chekining <b>rasmini (skrinshot)</b> yuboring yoki ❌ Bekor qilish tugmasini bosing.', {
        parse_mode: 'HTML',
      });
      return;
    }

    if (session.step === 'admin_broadcast' && store.isAdmin(ctx.from.id)) {
      sessions.set(ctx.from.id, { step: 'idle' });
      await ctx.reply('📤 Xabar barcha foydalanuvchilarga yuborilmoqda...');
      const result = await sendBroadcastFromAdmin(text);
      await ctx.reply(
        `✅ E‘lon tarqatish yakunlandi!\n\n` +
          `📨 Yuborildi: <b>${result.sentCount}</b>\n` +
          `⚠️ Yetkazilmadi: <b>${result.failedCount}</b>`,
        { parse_mode: 'HTML' }
      );
      return;
    }
  });

  return bot;
}

async function notifyAdminsNewOrder(order: Order) {
  if (!botInstance) return;
  const settings = store.getSettings();
  const kb = new InlineKeyboard()
    .text('✅ Tasdiqlash (Bajarildi)', `ord_approve:${order.id}`)
    .text('❌ Bekor qilish', `ord_reject:${order.id}`);

  const caption =
    `🔔 <b>Yangi buyurtma: ${order.id}</b>\n\n` +
    `📦 Xizmat: <b>${escapeHtml(order.productTitle)}</b> (${categoryLabel(order.category)})\n` +
    `👤 Mijoz: ${escapeHtml(order.firstName)} (${order.username ? `@${order.username}` : `ID: ${order.userId}`})\n` +
    `🎯 Qabul qiluvchi: <code>${escapeHtml(order.targetUsername)}</code>\n` +
    `💵 Summa: <b>${formatUzs(order.paidAmount)}</b>\n` +
    `🕒 Vaqt: ${new Date(order.createdAt).toLocaleString('uz-UZ')}`;

  for (const adminId of settings.adminIds) {
    try {
      if (order.receiptFileId) {
        await botInstance.api.sendPhoto(adminId, order.receiptFileId, {
          caption,
          parse_mode: 'HTML',
          reply_markup: kb,
        });
      } else {
        await botInstance.api.sendMessage(adminId, caption, {
          parse_mode: 'HTML',
          reply_markup: kb,
        });
      }
    } catch (err) {
      console.error(`[TelegramBot] Failed to notify admin ${adminId}:`, err);
    }
  }
}

export async function notifyUserOrderUpdate(order: Order) {
  if (!botInstance) return;
  try {
    if (order.status === 'completed') {
      await botInstance.api.sendMessage(
        order.userId,
        `🎉 <b>Buyurtmangiz bajarildi!</b>\n\n` +
          `🆔 Buyurtma: <b>${order.id}</b>\n` +
          `📦 Xizmat: <b>${escapeHtml(order.productTitle)}</b>\n` +
          `🎯 Qabul qiluvchi: <code>${escapeHtml(order.targetUsername)}</code>\n\n` +
          `Xaridingiz uchun rahmat! Yana buyurtma berish uchun menyudan foydalaning.`,
        { parse_mode: 'HTML' }
      );
    } else if (order.status === 'cancelled') {
      await botInstance.api.sendMessage(
        order.userId,
        `❌ <b>Buyurtma bekor qilindi</b>\n\n` +
          `🆔 Buyurtma: <b>${order.id}</b>\n` +
          `📦 Xizmat: <b>${escapeHtml(order.productTitle)}</b>\n` +
          (order.adminNote ? `📝 Izoh: ${escapeHtml(order.adminNote)}\n\n` : '\n') +
          `Savollar bo‘lsa operatorga murojaat qiling: ${escapeHtml(store.getSettings().supportUsername)}`,
        { parse_mode: 'HTML' }
      );
    }
  } catch (err) {
    console.error(`[TelegramBot] Failed to notify user ${order.userId}:`, err);
  }
}

export async function sendDirectMessage(telegramId: number, message: string): Promise<boolean> {
  if (!botInstance) return false;
  try {
    await botInstance.api.sendMessage(telegramId, message, { parse_mode: 'HTML' });
    return true;
  } catch (err) {
    console.error(`[TelegramBot] Failed to message ${telegramId}:`, err);
    return false;
  }
}

export async function sendBroadcastFromAdmin(message: string) {
  const users = store.getUsers().filter((u) => !u.isBanned);
  let sentCount = 0;
  let failedCount = 0;

  if (botInstance) {
    for (const user of users) {
      try {
        await botInstance.api.sendMessage(user.telegramId, message, { parse_mode: 'HTML' });
        sentCount++;
      } catch {
        failedCount++;
      }
      // Small delay to stay well within Telegram's 30 msg/sec rate limit
      await new Promise((r) => setTimeout(r, 40));
    }
  } else {
    failedCount = users.length;
  }

  return store.addBroadcastLog({
    message,
    sentCount,
    failedCount,
    totalTargets: users.length,
  });
}

function getTashkentDateAndTime(): { dateStr: string; timeStr: string } {
  const now = new Date();
  const dateStr = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Tashkent',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(now);
  const timeStr = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Tashkent',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(now);
  return { dateStr, timeStr };
}

export async function sendDailyAdminReport(markSentDate = false) {
  const settings = store.getSettings();
  const { dateStr } = getTashkentDateAndTime();
  const stats = store.getDailyReportStats(dateStr);

  const reportText =
    `📊 <b>Kunlik avtomatik hisobot (${escapeHtml(stats.dateStr)})</b>\n` +
    `🏪 Do‘kon: <b>${escapeHtml(settings.shopName)}</b>\n\n` +
    `💰 Bugungi savdo tushumi: <b>${formatUzs(stats.todayRevenue)}</b>\n` +
    `✅ Bugun bajarilgan buyurtmalar: <b>${stats.todayOrdersCount} ta</b>\n` +
    `⏳ Kutilayotgan buyurtmalar: <b>${stats.pendingOrdersCount} ta</b>\n` +
    `🏷 Bugun mijozlar tejagan summa: <b>${formatUzs(stats.todaySavings)}</b>\n\n` +
    `👥 Yangi foydalanuvchilar (bugun): <b>+${stats.todayNewUsersCount} ta</b>\n` +
    `🌐 Jami foydalanuvchilar: <b>${stats.totalUsersCount} ta</b>\n` +
    `📈 Umumiy savdo tushumi: <b>${formatUzs(stats.totalRevenue)}</b>`;

  let delivered = 0;
  if (botInstance) {
    for (const adminId of settings.adminIds) {
      const ok = await sendDirectMessage(adminId, reportText);
      if (ok) delivered++;
    }
  }

  if (markSentDate && delivered > 0) {
    store.updateSettings({ lastDailyReportDate: stats.dateStr });
  }

  return {
    delivered,
    totalAdmins: settings.adminIds.length,
    reportDate: stats.dateStr,
  };
}

async function checkAndSendScheduledDailyReport() {
  const settings = store.getSettings();
  if (!settings.dailyReportEnabled) return;

  const { dateStr, timeStr } = getTashkentDateAndTime();
  const targetTime = settings.dailyReportTime || '21:00';

  if (settings.lastDailyReportDate === dateStr) return;
  if (timeStr >= targetTime) {
    await sendDailyAdminReport(true);
  }
}

export async function getTelegramFileUrl(fileId: string): Promise<string | null> {
  if (!botInstance) return null;
  try {
    const file = await botInstance.api.getFile(fileId);
    if (!file.file_path) return null;
    const token = getBotToken();
    return `https://api.telegram.org/file/bot${token}/${file.file_path}`;
  } catch (err) {
    console.error('[TelegramBot] Failed to get file URL:', err);
    return null;
  }
}

async function runPollingLoop(bot: Bot) {
  while (!manualStop && botInstance === bot) {
    try {
      await bot.api.deleteWebhook({ drop_pending_updates: false }).catch(() => {});
      const me = await bot.api.getMe();
      runtimeStatus.running = true;
      runtimeStatus.pollingActive = true;
      runtimeStatus.connectionMode = 'polling';
      runtimeStatus.webhookUrl = null;
      runtimeStatus.pendingUpdatesCount = 0;
      runtimeStatus.botId = me.id;
      runtimeStatus.botUsername = me.username ?? null;
      runtimeStatus.botFirstName = me.first_name;
      runtimeStatus.lastHeartbeatAt = new Date().toISOString();
      runtimeStatus.lastError = null;
      if (!runtimeStatus.startedAt) {
        runtimeStatus.startedAt = new Date().toISOString();
      }

      console.log(`[TelegramBot] 24/7 Polling active as @${me.username} (ID: ${me.id})`);

      // Set bot commands menu
      await bot.api.setMyCommands([
        { command: 'start', description: 'Botni ishga tushirish / Bosh menyu' },
        { command: 'faq', description: 'Tez-tez so‘raladigan savollar (FAQ)' },
        { command: 'admin', description: 'Admin boshqaruv paneli' },
      ]).catch(() => {});

      await bot.start({
        drop_pending_updates: false,
        onStart: () => {
          runtimeStatus.pollingActive = true;
        },
      });
    } catch (err) {
      runtimeStatus.pollingActive = false;
      runtimeStatus.lastError = err instanceof Error ? err.message : String(err);
      console.error('[TelegramBot] Polling interrupted, restarting in 4s:', runtimeStatus.lastError);
    }

    if (!manualStop && botInstance === bot) {
      runtimeStatus.reconnectCount += 1;
      await new Promise((r) => setTimeout(r, 4000));
    }
  }
}

async function setupWebhookMode(bot: Bot, publicUrl: string) {
  const cleanBase = publicUrl.trim().replace(/\/+$/, '');
  const webhookTarget = `${cleanBase}/api/telegram/webhook`;

  await bot.init();
  const me = bot.botInfo;

  await bot.api.setMyCommands([
    { command: 'start', description: 'Botni ishga tushirish / Bosh menyu' },
    { command: 'faq', description: 'Tez-tez so‘raladigan savollar (FAQ)' },
    { command: 'admin', description: 'Admin boshqaruv paneli' },
  ]).catch(() => {});

  await bot.api.setWebhook(webhookTarget, { drop_pending_updates: false });
  const info = await bot.api.getWebhookInfo();

  runtimeStatus.running = true;
  runtimeStatus.pollingActive = false;
  runtimeStatus.connectionMode = 'webhook';
  runtimeStatus.webhookUrl = info.url || webhookTarget;
  runtimeStatus.pendingUpdatesCount = info.pending_update_count ?? 0;
  runtimeStatus.botId = me.id;
  runtimeStatus.botUsername = me.username ?? null;
  runtimeStatus.botFirstName = me.first_name;
  runtimeStatus.lastHeartbeatAt = new Date().toISOString();
  runtimeStatus.lastError = info.last_error_message ?? null;
  if (!runtimeStatus.startedAt) {
    runtimeStatus.startedAt = new Date().toISOString();
  }

  console.log(`[TelegramBot] 24/7 Webhook active at ${runtimeStatus.webhookUrl} for @${me.username}`);
}

export async function startBotWithWatchdog() {
  if (isStarting) return;
  isStarting = true;
  manualStop = false;

  try {
    const token = getBotToken();
    if (!token) {
      runtimeStatus.lastError = 'Bot token topilmadi';
      return;
    }

    if (botInstance) {
      try {
        await botInstance.stop();
      } catch {
        // ignore
      }
    }

    const bot = createBot(token);
    botInstance = bot;

    const settings = store.getSettings();
    if (settings.connectionMode === 'webhook' && settings.publicServerUrl.startsWith('https://')) {
      try {
        await setupWebhookMode(bot, settings.publicServerUrl);
      } catch (err) {
        runtimeStatus.lastError = err instanceof Error ? err.message : String(err);
        console.error('[TelegramBot] Webhook setup failed, falling back to polling:', runtimeStatus.lastError);
        void runPollingLoop(bot);
      }
    } else {
      // Launch non-blocking polling loop
      void runPollingLoop(bot);
    }

    // 30-second health watchdog
    if (watchdogTimer) clearInterval(watchdogTimer);
    watchdogTimer = setInterval(async () => {
      if (!botInstance || manualStop) return;
      try {
        const me = await botInstance.api.getMe();
        runtimeStatus.running = true;
        runtimeStatus.botId = me.id;
        runtimeStatus.botUsername = me.username ?? null;
        runtimeStatus.botFirstName = me.first_name;
        runtimeStatus.lastHeartbeatAt = new Date().toISOString();

        const currentSettings = store.getSettings();
        if (currentSettings.connectionMode === 'webhook' && currentSettings.publicServerUrl.startsWith('https://')) {
          const info = await botInstance.api.getWebhookInfo();
          const expected = `${currentSettings.publicServerUrl.trim().replace(/\/+$/, '')}/api/telegram/webhook`;
          runtimeStatus.webhookUrl = info.url || null;
          runtimeStatus.pendingUpdatesCount = info.pending_update_count ?? 0;
          runtimeStatus.lastError = info.last_error_message ?? null;
          if (info.url !== expected) {
            await botInstance.api.setWebhook(expected, { drop_pending_updates: false });
            runtimeStatus.webhookUrl = expected;
          }
        } else {
          runtimeStatus.lastError = null;
        }
      } catch (err) {
        runtimeStatus.lastError = err instanceof Error ? err.message : String(err);
        console.warn('[TelegramBot] Watchdog heartbeat warning:', runtimeStatus.lastError);
      }
    }, 30_000);

    // 60-second daily report scheduler
    if (reportTimer) clearInterval(reportTimer);
    reportTimer = setInterval(() => {
      void checkAndSendScheduledDailyReport();
    }, 60_000);
    void checkAndSendScheduledDailyReport();
  } finally {
    isStarting = false;
  }
}

export async function handleTelegramWebhook(req: Request, res: Response) {
  try {
    if (!botInstance) {
      const token = getBotToken();
      botInstance = createBot(token);
      await botInstance.init();
    } else if (!botInstance.isInited()) {
      await botInstance.init();
    }
    const handler = webhookCallback(botInstance, 'express');
    await handler(req, res);
  } catch (err) {
    console.error('[TelegramBot] Webhook update handling error:', err);
    if (!res.headersSent) {
      res.status(200).json({ ok: true });
    }
  }
}

export async function connectWebhook(publicUrl: string): Promise<BotRuntimeStatus> {
  const cleanBase = publicUrl.trim().replace(/\/+$/, '');
  if (!cleanBase.startsWith('https://')) {
    throw new Error('Webhook uchun manzil https:// bilan boshlanishi shart.');
  }

  manualStop = true;
  if (botInstance) {
    try {
      await botInstance.stop();
    } catch {
      // ignore
    }
  }

  store.updateSettings({
    connectionMode: 'webhook',
    publicServerUrl: cleanBase,
  });

  manualStop = false;
  const bot = createBot(getBotToken());
  botInstance = bot;
  await setupWebhookMode(bot, cleanBase);
  return getBotStatus();
}

export async function disconnectWebhook(): Promise<BotRuntimeStatus> {
  store.updateSettings({
    connectionMode: 'polling',
  });
  await restartBot();
  return getBotStatus();
}

export async function restartBot() {
  manualStop = true;
  if (botInstance) {
    try {
      await botInstance.stop();
    } catch {
      // ignore
    }
  }
  runtimeStatus.pollingActive = false;
  runtimeStatus.reconnectCount += 1;
  await startBotWithWatchdog();
}

export function getBotStatus(): BotRuntimeStatus {
  const uptimeSeconds = runtimeStatus.startedAt
    ? Math.max(0, Math.floor((Date.now() - Date.parse(runtimeStatus.startedAt)) / 1000))
    : 0;
  return {
    ...runtimeStatus,
    uptimeSeconds,
  };
}
