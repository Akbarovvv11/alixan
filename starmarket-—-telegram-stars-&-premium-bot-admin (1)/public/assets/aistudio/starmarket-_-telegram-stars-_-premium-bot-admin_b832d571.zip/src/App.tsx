import { useCallback, useEffect, useState } from 'react';
import {
  HelpCircle,
  LayoutDashboard,
  Megaphone,
  Menu,
  Package,
  RefreshCw,
  Settings,
  ShoppingBag,
  Users,
  X,
} from 'lucide-react';
import { BroadcastTab } from './components/BroadcastTab.tsx';
import { FaqTab } from './components/FaqTab.tsx';
import { OrdersTab } from './components/OrdersTab.tsx';
import { OverviewTab } from './components/OverviewTab.tsx';
import { ProductsTab } from './components/ProductsTab.tsx';
import { SettingsTab } from './components/SettingsTab.tsx';
import { UsersTab } from './components/UsersTab.tsx';
import type {
  BotRuntimeStatus,
  BotUser,
  BroadcastLog,
  DashboardSummary,
  FaqItem,
  Order,
  OrderStatus,
  Product,
  ProductCategory,
  ShopSettings,
} from './types.ts';

type NavTab = 'overview' | 'orders' | 'products' | 'users' | 'faq' | 'broadcast' | 'settings';

interface BootstrapPayload {
  status: BotRuntimeStatus;
  summary: DashboardSummary;
  products: Product[];
  orders: Order[];
  users: BotUser[];
  broadcasts: BroadcastLog[];
  faqs: FaqItem[];
  settings: ShopSettings;
  appUrl: string | null;
}

const TAB_LABELS: Record<NavTab, string> = {
  overview: 'Umumiy ko‘rinish',
  orders: 'Buyurtmalar',
  products: 'Mahsulotlar va Narxlar',
  users: 'Foydalanuvchilar',
  faq: 'Savol-javob (FAQ)',
  broadcast: 'Xabar tarqatish',
  settings: 'To‘lov va Bot sozlamalari',
};

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [data, setData] = useState<BootstrapPayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [pingBusy, setPingBusy] = useState(false);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const showToast = useCallback((type: 'success' | 'error', text: string) => {
    setToast({ type, text });
    setTimeout(() => {
      setToast((prev) => (prev?.text === text ? null : prev));
    }, 3500);
  }, []);

  const fetchBootstrap = useCallback(async (silent = false) => {
    if (!silent) setRefreshing(true);
    try {
      const res = await fetch('/api/bootstrap');
      if (!res.ok) throw new Error('Serverdan ma’lumot olinmadi');
      const json = (await res.json()) as BootstrapPayload;
      setData(json);
    } catch (err) {
      if (!silent) {
        showToast('error', err instanceof Error ? err.message : 'Ulanish xatoligi');
      }
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [showToast]);

  useEffect(() => {
    void fetchBootstrap(true);
    const interval = setInterval(() => {
      void fetchBootstrap(true);
    }, 10_000);
    return () => clearInterval(interval);
  }, [fetchBootstrap]);

  async function handleUpdateOrderStatus(orderId: string, status: OrderStatus, adminNote?: string) {
    try {
      const res = await fetch(`/api/orders/${encodeURIComponent(orderId)}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, adminNote }),
      });
      if (!res.ok) throw new Error('Buyurtma holatini yangilab bo‘lmadi');
      await fetchBootstrap(true);
      showToast(
        'success',
        status === 'completed'
          ? `${orderId} tasdiqlandi va mijozga xabar yuborildi`
          : status === 'cancelled'
          ? `${orderId} bekor qilindi`
          : `${orderId} qayta tekshiruvga o‘tkazildi`
      );
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Xatolik yuz berdi');
    }
  }

  async function handleCreateProduct(input: Omit<Product, 'id' | 'sortOrder'>) {
    try {
      const res = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(input),
      });
      if (!res.ok) throw new Error('Mahsulot qo‘shilmadi');
      await fetchBootstrap(true);
      showToast('success', 'Yangi tarif qo‘shildi');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Xatolik');
    }
  }

  async function handleUpdateProduct(id: string, patch: Partial<Product>) {
    try {
      const res = await fetch(`/api/products/${encodeURIComponent(id)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(patch),
      });
      if (!res.ok) throw new Error('Tarif yangilanmadi');
      await fetchBootstrap(true);
      showToast('success', 'Tarif saqlandi');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Xatolik');
    }
  }

  async function handleDeleteProduct(id: string) {
    try {
      const res = await fetch(`/api/products/${encodeURIComponent(id)}`, {
        method: 'DELETE',
      });
      if (!res.ok) throw new Error('Tarif o‘chirilmadi');
      await fetchBootstrap(true);
      showToast('success', 'Tarif o‘chirildi');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Xatolik');
    }
  }

  async function handleBulkDiscount(percentBelowMarket: number, category?: ProductCategory) {
    try {
      const res = await fetch('/api/products/bulk-discount', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ percentBelowMarket, category }),
      });
      if (!res.ok) throw new Error('Chegirma qo‘llanmadi');
      await fetchBootstrap(true);
      showToast('success', `Bozor narxidan ${percentBelowMarket}% chegirma qo‘llandi`);
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Xatolik');
    }
  }

  async function handleUpdateUser(telegramId: number, patch: Partial<BotUser>) {
    try {
      const res = await fetch(`/api/users/${telegramId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(patch),
      });
      if (!res.ok) throw new Error('Foydalanuvchi yangilanmadi');
      await fetchBootstrap(true);
      showToast('success', 'Foydalanuvchi ma’lumotlari saqlandi');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Xatolik');
    }
  }

  async function handleSendDirectMessage(telegramId: number, message: string) {
    try {
      const res = await fetch(`/api/users/${telegramId}/message`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error || 'Xabar yuborilmadi');
      }
      showToast('success', 'Xabar Telegram orqali yuborildi');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Xatolik');
    }
  }

  async function handleSendBroadcast(message: string) {
    try {
      const res = await fetch('/api/broadcast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message }),
      });
      if (!res.ok) throw new Error('Xabar tarqatilmadi');
      const result = await res.json();
      await fetchBootstrap(true);
      showToast(
        'success',
        `E‘lon yuborildi: ${result.log.sentCount} ta muvaffaqiyatli, ${result.log.failedCount} ta xato`
      );
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Xatolik');
    }
  }

  async function handleSaveSettings(patch: Partial<ShopSettings>) {
    try {
      const res = await fetch('/api/settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(patch),
      });
      if (!res.ok) throw new Error('Sozlamalar saqlanmadi');
      await fetchBootstrap(true);
      showToast('success', 'Sozlamalar muvaffaqiyatli saqlandi');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Xatolik');
    }
  }

  async function handleRestartBot() {
    try {
      const res = await fetch('/api/bot/restart', { method: 'POST' });
      if (!res.ok) throw new Error('Bot qayta ulanmadi');
      await fetchBootstrap(true);
      showToast('success', 'Telegram bot ulanishi yangilandi');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Xatolik');
    }
  }

  async function handleTestAdminPing() {
    setPingBusy(true);
    try {
      const res = await fetch('/api/bot/test-admin-ping', { method: 'POST' });
      const json = await res.json();
      if (json.delivered > 0) {
        showToast('success', 'Admin Telegram hisobingizga test xabar yuborildi!');
      } else {
        showToast(
          'error',
          'Xabar bormadi — avval Telegramda botga kirib /start bosing (ID: 6926818540).'
        );
      }
    } catch {
      showToast('error', 'Test xabar yuborishda xatolik');
    } finally {
      setPingBusy(false);
    }
  }

  async function handleSendDailyReport() {
    try {
      const res = await fetch('/api/bot/send-daily-report', { method: 'POST' });
      const json = await res.json();
      if (json.delivered > 0) {
        showToast('success', 'Kunlik hisobot admin Telegram hisobingizga yuborildi!');
      } else {
        showToast(
          'error',
          'Hisobot yuborilmadi — avval Telegramda botga kirib /start bosing (ID: 6926818540).'
        );
      }
    } catch {
      showToast('error', 'Kunlik hisobot yuborishda xatolik');
    }
  }

  async function handleConnectWebhook(publicServerUrl: string) {
    try {
      const res = await fetch('/api/bot/connect-webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ publicServerUrl }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Webhook ulanmadi');
      await fetchBootstrap(true);
      showToast('success', '24/7 Telegram Webhook muvaffaqiyatli ulandi!');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Webhook ulashda xatolik');
    }
  }

  async function handleDisconnectWebhook() {
    try {
      const res = await fetch('/api/bot/disconnect-webhook', { method: 'POST' });
      if (!res.ok) throw new Error('Polling rejimiga o‘tib bo‘lmadi');
      await fetchBootstrap(true);
      showToast('success', 'Long Polling 24/7 rejimiga o‘tildi');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Xatolik');
    }
  }

  async function handleCreateFaq(input: { question: string; answer: string; active: boolean }) {
    try {
      const res = await fetch('/api/faqs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(input),
      });
      if (!res.ok) throw new Error('Savol qo‘shilmadi');
      await fetchBootstrap(true);
      showToast('success', 'Yangi savol-javob qo‘shildi');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Xatolik');
    }
  }

  async function handleUpdateFaq(
    id: string,
    patch: Partial<Pick<FaqItem, 'question' | 'answer' | 'active' | 'sortOrder'>>
  ) {
    try {
      const res = await fetch(`/api/faqs/${encodeURIComponent(id)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(patch),
      });
      if (!res.ok) throw new Error('Savol-javob yangilanmadi');
      await fetchBootstrap(true);
      showToast('success', 'Savol-javob saqlandi');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Xatolik');
    }
  }

  async function handleDeleteFaq(id: string) {
    try {
      const res = await fetch(`/api/faqs/${encodeURIComponent(id)}`, {
        method: 'DELETE',
      });
      if (!res.ok) throw new Error('Savol-javob o‘chirilmadi');
      await fetchBootstrap(true);
      showToast('success', 'Savol-javob o‘chirildi');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Xatolik');
    }
  }

  const navItems: Array<{ id: NavTab; label: string; icon: typeof LayoutDashboard; count?: number }> = [
    { id: 'overview', label: 'Umumiy ko‘rinish', icon: LayoutDashboard },
    {
      id: 'orders',
      label: 'Buyurtmalar',
      icon: ShoppingBag,
      count: data?.summary.pendingOrdersCount || undefined,
    },
    { id: 'products', label: 'Mahsulotlar va Narxlar', icon: Package },
    { id: 'users', label: 'Foydalanuvchilar', icon: Users },
    { id: 'faq', label: 'Savol-javob (FAQ)', icon: HelpCircle },
    { id: 'broadcast', label: 'Xabar tarqatish', icon: Megaphone },
    { id: 'settings', label: 'Sozlamalar', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 bg-white border-r border-slate-200">
        <div className="h-16 px-6 flex items-center border-b border-slate-200">
          <span className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0">
            {data?.settings.shopName || 'StarMarket UZ'}
          </span>
        </div>

        <nav className="flex-1 p-3 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-sky-50 text-sky-700'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <span className="flex items-center gap-3 min-w-0">
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </span>
                {item.count !== undefined && item.count > 0 && (
                  <span className="font-mono tabular-nums text-xs font-semibold text-amber-700">
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-200 text-xs text-slate-500 space-y-1">
          <div className="flex items-center justify-between">
            <span>Bot holati</span>
            <span className={data?.status.running ? 'text-emerald-700 font-medium' : 'text-amber-700'}>
              {data?.status.running
                ? data?.status.connectionMode === 'webhook'
                  ? '24/7 Webhook'
                  : '24/7 Faol'
                : 'Ulanmoqda'}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span>Admin ID</span>
            <span className="font-mono tabular-nums text-slate-800">
              {data?.settings.adminIds[0] ?? 6926818540}
            </span>
          </div>
        </div>
      </aside>

      {/* Mobile Sidebar Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/50"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative w-64 max-w-[80vw] bg-white h-full border-r border-slate-200 flex flex-col">
            <div className="h-14 px-5 flex items-center justify-between border-b border-slate-200">
              <span className="text-base font-bold text-slate-900">
                {data?.settings.shopName || 'StarMarket UZ'}
              </span>
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="p-1.5 text-slate-500 hover:text-slate-900"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <nav className="flex-1 p-3 space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const active = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center justify-between gap-3 px-3 py-2.5 text-sm font-medium rounded-lg ${
                      active ? 'bg-sky-50 text-sky-700' : 'text-slate-600'
                    }`}
                  >
                    <span className="flex items-center gap-3">
                      <Icon className="w-4 h-4" />
                      {item.label}
                    </span>
                    {item.count !== undefined && item.count > 0 && (
                      <span className="font-mono tabular-nums text-xs font-semibold text-amber-700">
                        {item.count}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 md:pl-64 flex flex-col min-w-0">
        {/* Top Header Contract */}
        <header className="h-16 bg-white border-b border-slate-200 px-4 sm:px-8 flex items-center justify-between gap-4 sticky top-0 z-30">
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="md:hidden p-2 -ml-2 text-slate-600 hover:text-slate-900 rounded-lg"
              aria-label="Menyu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-sm truncate">
              <span className="text-slate-400 hidden sm:inline">Admin Panel</span>
              <span className="text-slate-300 hidden sm:inline">/</span>
              <h1 className="font-semibold text-slate-900 truncate">{TAB_LABELS[activeTab]}</h1>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => fetchBootstrap(false)}
              disabled={refreshing}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
              Yangilash
            </button>
          </div>
        </header>

        {/* Viewport Body */}
        <main className="flex-1 p-4 sm:p-8 max-w-[1280px] w-full mx-auto">
          {loading || !data ? (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {[1, 2, 3, 4].map((i) => (
                  <div
                    key={i}
                    className="h-28 bg-white border border-slate-200 rounded-xl p-5 animate-pulse"
                  >
                    <div className="h-3 w-24 bg-slate-200 rounded" />
                    <div className="h-7 w-32 bg-slate-200 rounded mt-4" />
                  </div>
                ))}
              </div>
              <div className="h-64 bg-white border border-slate-200 rounded-xl animate-pulse" />
            </div>
          ) : (
            <>
              {activeTab === 'overview' && (
                <OverviewTab
                  status={data.status}
                  summary={data.summary}
                  orders={data.orders}
                  settings={data.settings}
                  onUpdateOrderStatus={(id, s) => handleUpdateOrderStatus(id, s)}
                  onNavigateTab={(t) => setActiveTab(t)}
                  onTestAdminPing={handleTestAdminPing}
                  pingBusy={pingBusy}
                />
              )}

              {activeTab === 'orders' && (
                <OrdersTab
                  orders={data.orders}
                  onUpdateOrderStatus={handleUpdateOrderStatus}
                />
              )}

              {activeTab === 'products' && (
                <ProductsTab
                  products={data.products}
                  onCreateProduct={handleCreateProduct}
                  onUpdateProduct={handleUpdateProduct}
                  onDeleteProduct={handleDeleteProduct}
                  onBulkDiscount={handleBulkDiscount}
                />
              )}

              {activeTab === 'users' && (
                <UsersTab
                  users={data.users}
                  adminIds={data.settings.adminIds}
                  onUpdateUser={handleUpdateUser}
                  onSendMessage={handleSendDirectMessage}
                />
              )}

              {activeTab === 'faq' && (
                <FaqTab
                  faqs={data.faqs || []}
                  onCreateFaq={handleCreateFaq}
                  onUpdateFaq={handleUpdateFaq}
                  onDeleteFaq={handleDeleteFaq}
                />
              )}

              {activeTab === 'broadcast' && (
                <BroadcastTab
                  totalUsers={data.users.length}
                  broadcasts={data.broadcasts}
                  onSendBroadcast={handleSendBroadcast}
                />
              )}

              {activeTab === 'settings' && (
                <SettingsTab
                  settings={data.settings}
                  status={data.status}
                  appUrl={data.appUrl}
                  onSaveSettings={handleSaveSettings}
                  onRestartBot={handleRestartBot}
                  onSendDailyReport={handleSendDailyReport}
                  onConnectWebhook={handleConnectWebhook}
                  onDisconnectWebhook={handleDisconnectWebhook}
                />
              )}
            </>
          )}
        </main>
      </div>

      {/* Toast Notification */}
      {toast && (
        <div
          className={`fixed bottom-5 right-5 z-50 px-4 py-3 rounded-lg border text-sm font-medium shadow-lg transition-all ${
            toast.type === 'success'
              ? 'bg-white border-emerald-200 text-emerald-800'
              : 'bg-white border-rose-200 text-rose-800'
          }`}
        >
          {toast.text}
        </div>
      )}
    </div>
  );
}
