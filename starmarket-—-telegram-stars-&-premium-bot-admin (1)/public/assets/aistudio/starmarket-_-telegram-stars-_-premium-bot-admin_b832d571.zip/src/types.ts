export type ProductCategory = 'stars' | 'premium' | 'gifts' | 'boost';

export type OrderStatus = 'awaiting_payment' | 'pending_review' | 'completed' | 'cancelled';

export type BotConnectionMode = 'polling' | 'webhook';

export interface Product {
  id: string;
  category: ProductCategory;
  title: string;
  description: string;
  amountLabel: string;
  marketPrice: number;
  ourPrice: number;
  active: boolean;
  sortOrder: number;
}

export interface BotUser {
  telegramId: number;
  username: string | null;
  firstName: string;
  lastName: string | null;
  balance: number;
  ordersCount: number;
  totalSpent: number;
  isBanned: boolean;
  referredBy: number | null;
  joinedAt: string;
  lastActiveAt: string;
}

export interface Order {
  id: string;
  userId: number;
  username: string | null;
  firstName: string;
  productId: string;
  productTitle: string;
  category: ProductCategory;
  targetUsername: string;
  marketPrice: number;
  paidAmount: number;
  receiptFileId: string | null;
  receiptCaption: string | null;
  status: OrderStatus;
  adminNote: string | null;
  createdAt: string;
  updatedAt: string;
  completedBy: number | null;
}

export interface BroadcastLog {
  id: string;
  message: string;
  sentCount: number;
  failedCount: number;
  totalTargets: number;
  createdAt: string;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  active: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export interface ShopSettings {
  shopName: string;
  adminIds: number[];
  supportUsername: string;
  cardNumber: string;
  cardHolder: string;
  paymentNote: string;
  maintenanceMode: boolean;
  welcomeMessage: string;
  referralBonusPercent: number;
  requireWebOtp: boolean;
  dailyReportEnabled: boolean;
  dailyReportTime: string;
  lastDailyReportDate: string | null;
  connectionMode: BotConnectionMode;
  publicServerUrl: string;
}

export interface BotRuntimeStatus {
  running: boolean;
  pollingActive: boolean;
  connectionMode: BotConnectionMode;
  webhookUrl: string | null;
  pendingUpdatesCount: number;
  botId: number | null;
  botUsername: string | null;
  botFirstName: string | null;
  startedAt: string | null;
  uptimeSeconds: number;
  lastHeartbeatAt: string | null;
  lastError: string | null;
  reconnectCount: number;
}

export interface DashboardSummary {
  totalRevenue: number;
  totalSavingsForUsers: number;
  pendingOrdersCount: number;
  completedOrdersCount: number;
  cancelledOrdersCount: number;
  totalUsersCount: number;
  activeProductsCount: number;
  dailyRevenue: Array<{
    date: string;
    label: string;
    revenue: number;
    orders: number;
  }>;
}
