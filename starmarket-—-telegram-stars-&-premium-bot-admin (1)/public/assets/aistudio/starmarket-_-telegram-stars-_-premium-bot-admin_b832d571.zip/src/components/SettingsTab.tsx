import { useState } from 'react';
import { BarChart3, Copy, Globe, RefreshCw, Save } from 'lucide-react';
import type { BotRuntimeStatus, ShopSettings } from '../types.ts';

interface SettingsTabProps {
  settings: ShopSettings;
  status: BotRuntimeStatus;
  appUrl: string | null;
  onSaveSettings: (patch: Partial<ShopSettings>) => Promise<void>;
  onRestartBot: () => Promise<void>;
  onSendDailyReport: () => Promise<void>;
  onConnectWebhook: (publicServerUrl: string) => Promise<void>;
  onDisconnectWebhook: () => Promise<void>;
}

export function SettingsTab({
  settings,
  status,
  appUrl,
  onSaveSettings,
  onRestartBot,
  onSendDailyReport,
  onConnectWebhook,
  onDisconnectWebhook,
}: SettingsTabProps) {
  const [shopName, setShopName] = useState(settings.shopName);
  const [cardNumber, setCardNumber] = useState(settings.cardNumber);
  const [cardHolder, setCardHolder] = useState(settings.cardHolder);
  const [paymentNote, setPaymentNote] = useState(settings.paymentNote);
  const [supportUsername, setSupportUsername] = useState(settings.supportUsername);
  const [welcomeMessage, setWelcomeMessage] = useState(settings.welcomeMessage);
  const [referralBonusPercent, setReferralBonusPercent] = useState(
    String(settings.referralBonusPercent)
  );
  const [adminIdsRaw, setAdminIdsRaw] = useState(settings.adminIds.join(', '));
  const [maintenanceMode, setMaintenanceMode] = useState(settings.maintenanceMode);
  const [dailyReportEnabled, setDailyReportEnabled] = useState(Boolean(settings.dailyReportEnabled));
  const [dailyReportTime, setDailyReportTime] = useState(settings.dailyReportTime || '21:00');
  const [publicServerUrl, setPublicServerUrl] = useState(settings.publicServerUrl || '');
  const [saving, setSaving] = useState(false);
  const [restarting, setRestarting] = useState(false);
  const [sendingReport, setSendingReport] = useState(false);
  const [webhookBusy, setWebhookBusy] = useState(false);
  const [copiedHealth, setCopiedHealth] = useState(false);

  const healthUrl = `${(appUrl || window.location.origin).replace(/\/$/, '')}/health`;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      const parsedAdmins = adminIdsRaw
        .split(/[,\s]+/)
        .map((v) => Number(v.trim()))
        .filter((n) => !Number.isNaN(n) && n > 0);

      await onSaveSettings({
        shopName: shopName.trim(),
        cardNumber: cardNumber.trim(),
        cardHolder: cardHolder.trim(),
        paymentNote: paymentNote.trim(),
        supportUsername: supportUsername.trim(),
        welcomeMessage: welcomeMessage.trim(),
        referralBonusPercent: Math.max(0, Math.min(30, Number(referralBonusPercent) || 0)),
        adminIds: parsedAdmins,
        maintenanceMode,
        dailyReportEnabled,
        dailyReportTime: dailyReportTime || '21:00',
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <form
        onSubmit={handleSubmit}
        className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-6 space-y-5"
      >
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">To‘lov va Do‘kon sozlamalari</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Botda xaridorlarga ko‘rsatiladigan karta raqami va admin huquqlari
            </p>
          </div>
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-sky-600 hover:bg-sky-700 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Save className="w-4 h-4" />
            {saving ? 'Saqlanmoqda...' : 'Saqlash'}
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Do‘kon nomi</label>
            <input
              type="text"
              value={shopName}
              onChange={(e) => setShopName(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Operator (@username)
            </label>
            <input
              type="text"
              value={supportUsername}
              onChange={(e) => setSupportUsername(e.target.value)}
              className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              To‘lov karta raqami (Uzcard / Humo)
            </label>
            <input
              type="text"
              value={cardNumber}
              onChange={(e) => setCardNumber(e.target.value)}
              className="w-full px-3 py-2 text-sm font-mono tabular-nums border border-slate-200 rounded-lg"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Karta egasi</label>
            <input
              type="text"
              value={cardHolder}
              onChange={(e) => setCardHolder(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-700 mb-1">
            To‘lov oynasidagi ko‘rsatma matni
          </label>
          <textarea
            rows={2}
            value={paymentNote}
            onChange={(e) => setPaymentNote(e.target.value)}
            className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-700 mb-1">
            Salomlashish xabari (/start)
          </label>
          <textarea
            rows={3}
            value={welcomeMessage}
            onChange={(e) => setWelcomeMessage(e.target.value)}
            className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Admin Telegram ID raqamlari (vergul bilan)
            </label>
            <input
              type="text"
              value={adminIdsRaw}
              onChange={(e) => setAdminIdsRaw(e.target.value)}
              className="w-full px-3 py-2 text-sm font-mono tabular-nums border border-slate-200 rounded-lg"
            />
            <p className="text-[11px] text-slate-500 mt-1">
              Asosiy admin ID 6926818540 doim saqlanib qoladi.
            </p>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Referal bonus (%)
            </label>
            <input
              type="number"
              min={0}
              max={30}
              value={referralBonusPercent}
              onChange={(e) => setReferralBonusPercent(e.target.value)}
              className="w-full px-3 py-2 text-sm font-mono tabular-nums border border-slate-200 rounded-lg"
            />
          </div>
        </div>

        <div className="pt-3 flex items-center justify-between gap-4 border-t border-slate-100">
          <div>
            <p className="text-sm font-medium text-slate-900">Texnik tanaffus rejimi</p>
            <p className="text-xs text-slate-500">
              Yoqilganda oddiy foydalanuvchilar vaqtincha buyurtma bera olmaydi.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setMaintenanceMode(!maintenanceMode)}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              maintenanceMode
                ? 'bg-rose-600 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            {maintenanceMode ? 'Yoqilgan (Tanaffus)' : 'O‘chirilgan (Ochiq)'}
          </button>
        </div>

        <div className="pt-4 border-t border-slate-100 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <p className="text-sm font-medium text-slate-900">
                Kunlik avtomatik Telegram hisoboti
              </p>
              <p className="text-xs text-slate-500 mt-0.5">
                Har kuni belgilangan vaqtda (Toshkent vaqti) jami savdo va yangi foydalanuvchilar o‘sishi admin Telegramiga yuboriladi.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setDailyReportEnabled(!dailyReportEnabled)}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 self-start sm:self-center ${
                dailyReportEnabled
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {dailyReportEnabled ? 'Yoqilgan (Avto)' : 'O‘chirilgan'}
            </button>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div className="flex items-center gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Yuborish vaqti (Toshkent)
                </label>
                <input
                  type="time"
                  value={dailyReportTime}
                  onChange={(e) => setDailyReportTime(e.target.value)}
                  className="px-3 py-2 text-sm font-mono tabular-nums border border-slate-200 rounded-lg bg-white"
                />
              </div>
              {settings.lastDailyReportDate && (
                <div className="text-xs text-slate-500 pt-4">
                  So‘nggi hisobot:{' '}
                  <span className="font-mono tabular-nums text-slate-800">
                    {settings.lastDailyReportDate}
                  </span>
                </div>
              )}
            </div>

            <button
              type="button"
              disabled={sendingReport}
              onClick={async () => {
                setSendingReport(true);
                try {
                  await onSendDailyReport();
                } finally {
                  setSendingReport(false);
                }
              }}
              className="inline-flex items-center justify-center gap-2 px-3.5 py-2 text-xs font-medium text-sky-700 bg-sky-50 hover:bg-sky-100 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <BarChart3 className="w-3.5 h-3.5" />
              {sendingReport ? 'Yuborilmoqda...' : 'Hisobotni hozir yuborish'}
            </button>
          </div>
        </div>
      </form>

      {/* 24/7 Uptime & Server Connection Panel */}
      <div className="space-y-4">
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-base font-semibold text-slate-900">24/7 Server Ulanishi</h3>
            <span
              className={`text-xs font-medium ${
                status.running ? 'text-emerald-700' : 'text-amber-700'
              }`}
            >
              {status.connectionMode === 'webhook' ? 'Webhook Faol' : 'Polling Faol'}
            </span>
          </div>

          <p className="text-xs text-slate-500 leading-relaxed">
            Loyiha 24/7 ishlashi uchun 2 ta rejim mavjud: ichki avtomatik tiklanuvchi <b>Long Polling</b> va serverni har xabarda uyg‘otuvchi <b>Telegram Webhook</b>.
          </p>

          <div className="pt-2 border-t border-slate-100 space-y-2">
            <label className="block text-xs font-medium text-slate-700">
              Public Server manzili (Deploy qilingan HTTPS URL)
            </label>
            <input
              type="url"
              value={publicServerUrl}
              onChange={(e) => setPublicServerUrl(e.target.value)}
              placeholder="https://sizning-domeningiz.run.app"
              className="w-full px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg text-slate-800"
            />
            {status.webhookUrl && (
              <p className="text-[11px] text-emerald-700 font-mono break-all">
                Ulangan webhook: {status.webhookUrl}
              </p>
            )}
            <div className="flex flex-col sm:flex-row gap-2 pt-1">
              <button
                type="button"
                disabled={webhookBusy || !publicServerUrl.trim()}
                onClick={async () => {
                  setWebhookBusy(true);
                  try {
                    await onConnectWebhook(publicServerUrl.trim());
                  } finally {
                    setWebhookBusy(false);
                  }
                }}
                className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-white bg-sky-600 hover:bg-sky-700 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                <Globe className="w-3.5 h-3.5" />
                {webhookBusy ? 'Ulanmoqda...' : '24/7 Webhook ni ulash'}
              </button>
              {status.connectionMode === 'webhook' && (
                <button
                  type="button"
                  disabled={webhookBusy}
                  onClick={async () => {
                    setWebhookBusy(true);
                    try {
                      await onDisconnectWebhook();
                    } finally {
                      setWebhookBusy(false);
                    }
                  }}
                  className="px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  Polling ga qaytish
                </button>
              )}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 space-y-2">
            <p className="text-xs font-medium text-slate-700">
              Tashqi 24/7 Keep-Alive (/health manzili)
            </p>
            <div className="flex items-center gap-2">
              <input
                readOnly
                value={healthUrl}
                className="flex-1 px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg text-slate-700"
              />
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(healthUrl).catch(() => {});
                  setCopiedHealth(true);
                  setTimeout(() => setCopiedHealth(false), 2000);
                }}
                className="px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <Copy className="w-3.5 h-3.5" />
                {copiedHealth ? 'Nusxalandi' : 'Nusxalash'}
              </button>
            </div>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              Deploy qilganingizdan so‘ng ushbu /health manzilini UptimeRobot.com (5 daqiqalik HTTP ping) ga qo‘shsangiz server hech qachon uxlamaydi.
            </p>
          </div>

          <button
            type="button"
            disabled={restarting}
            onClick={async () => {
              setRestarting(true);
              try {
                await onRestartBot();
              } finally {
                setRestarting(false);
              }
            }}
            className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium text-slate-800 bg-slate-100 hover:bg-slate-200 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${restarting ? 'animate-spin' : ''}`} />
            {restarting ? 'Qayta ulanmoqda...' : 'Bot ulanishini yangilash'}
          </button>
        </div>
      </div>
    </div>
  );
}
