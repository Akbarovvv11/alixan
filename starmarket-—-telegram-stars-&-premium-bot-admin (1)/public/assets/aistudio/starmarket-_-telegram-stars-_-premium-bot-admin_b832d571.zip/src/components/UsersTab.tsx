import { useMemo, useState } from 'react';
import { Ban, MessageSquare, Search, ShieldCheck, Wallet, X } from 'lucide-react';
import type { BotUser } from '../types.ts';
import { formatDateTime, formatUzs } from '../utils/format.ts';

interface UsersTabProps {
  users: BotUser[];
  adminIds: number[];
  onUpdateUser: (telegramId: number, patch: Partial<BotUser>) => Promise<void>;
  onSendMessage: (telegramId: number, message: string) => Promise<void>;
}

export function UsersTab({ users, adminIds, onUpdateUser, onSendMessage }: UsersTabProps) {
  const [query, setQuery] = useState('');
  const [messageTarget, setMessageTarget] = useState<BotUser | null>(null);
  const [messageText, setMessageText] = useState('');
  const [balanceTarget, setBalanceTarget] = useState<BotUser | null>(null);
  const [balanceValue, setBalanceValue] = useState('0');
  const [sending, setSending] = useState(false);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return users;
    return users.filter(
      (u) =>
        u.firstName.toLowerCase().includes(q) ||
        (u.username || '').toLowerCase().includes(q) ||
        String(u.telegramId).includes(q)
    );
  }, [users, query]);

  return (
    <div className="space-y-4">
      <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-semibold text-slate-900">Bot foydalanuvchilari ({users.length})</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Botga /start bosgan barcha mijozlar, ularning xarid tarixi va bonus balansi
          </p>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ism, @username yoki ID..."
            className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-600"
          />
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        {filtered.length === 0 ? (
          <div className="px-6 py-14 text-center">
            <p className="text-sm font-medium text-slate-900">Hali foydalanuvchilar yo‘q</p>
            <p className="text-xs text-slate-500 mt-1">
              Foydalanuvchilar Telegram botingizga /start bosgandan so‘ng avtomatik ro‘yxatga olinadi.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-medium text-slate-500">
                  <th className="py-3 px-6">Foydalanuvchi</th>
                  <th className="py-3 px-4">Telegram ID</th>
                  <th className="py-3 px-4 text-right">Xaridlar</th>
                  <th className="py-3 px-4 text-right">Jami sarf</th>
                  <th className="py-3 px-4 text-right">Bonus balans</th>
                  <th className="py-3 px-4">So‘nggi faollik</th>
                  <th className="py-3 px-6 text-right">Amallar</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filtered.map((user) => {
                  const isAdmin = adminIds.includes(user.telegramId);
                  return (
                    <tr key={user.telegramId} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 px-6">
                        <div className="font-medium text-slate-900">
                          {user.firstName} {user.lastName || ''}
                          {isAdmin && (
                            <span className="ml-2 text-xs font-medium text-sky-700">· Admin</span>
                          )}
                          {user.isBanned && (
                            <span className="ml-2 text-xs font-medium text-rose-700">· Bloklangan</span>
                          )}
                        </div>
                        <div className="text-xs text-slate-500 font-mono">
                          {user.username ? `@${user.username}` : 'Username yo‘q'}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 font-mono tabular-nums text-xs text-slate-700">
                        {user.telegramId}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono tabular-nums text-slate-900">
                        {user.ordersCount}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono tabular-nums text-slate-900">
                        {formatUzs(user.totalSpent)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono tabular-nums text-emerald-700 font-medium">
                        {formatUzs(user.balance)}
                      </td>
                      <td className="py-3.5 px-4 text-xs text-slate-500 tabular-nums">
                        {formatDateTime(user.lastActiveAt)}
                      </td>
                      <td className="py-3.5 px-6 text-right">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            onClick={() => {
                              setBalanceTarget(user);
                              setBalanceValue(String(user.balance));
                            }}
                            className="p-1.5 text-slate-500 hover:text-sky-700 hover:bg-sky-50 rounded-md"
                            title="Balansni tahrirlash"
                          >
                            <Wallet className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              setMessageTarget(user);
                              setMessageText('');
                            }}
                            className="p-1.5 text-slate-500 hover:text-sky-700 hover:bg-sky-50 rounded-md"
                            title="Shaxsiy xabar yuborish"
                          >
                            <MessageSquare className="w-4 h-4" />
                          </button>
                          {!isAdmin && (
                            <button
                              onClick={() =>
                                onUpdateUser(user.telegramId, { isBanned: !user.isBanned })
                              }
                              className={`p-1.5 rounded-md ${
                                user.isBanned
                                  ? 'text-emerald-700 hover:bg-emerald-50'
                                  : 'text-slate-500 hover:text-rose-700 hover:bg-rose-50'
                              }`}
                              title={user.isBanned ? 'Blokdan chiqarish' : 'Bloklash'}
                            >
                              {user.isBanned ? (
                                <ShieldCheck className="w-4 h-4" />
                              ) : (
                                <Ban className="w-4 h-4" />
                              )}
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Direct Message Modal */}
      {messageTarget && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6 shadow-xl">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-semibold text-slate-900">
                Xabar yuborish · {messageTarget.firstName}
              </h3>
              <button onClick={() => setMessageTarget(null)} className="text-slate-400 hover:text-slate-700">
                <X className="w-4 h-4" />
              </button>
            </div>
            <textarea
              rows={4}
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              placeholder="Foydalanuvchiga Telegram bot nomidan xabar yozing..."
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
            />
            <div className="mt-4 flex justify-end gap-2">
              <button
                onClick={() => setMessageTarget(null)}
                className="px-4 py-2 text-xs font-medium text-slate-700 bg-slate-100 rounded-lg"
              >
                Bekor qilish
              </button>
              <button
                disabled={sending || !messageText.trim()}
                onClick={async () => {
                  setSending(true);
                  try {
                    await onSendMessage(messageTarget.telegramId, messageText.trim());
                    setMessageTarget(null);
                  } finally {
                    setSending(false);
                  }
                }}
                className="px-4 py-2 text-xs font-medium text-white bg-sky-600 hover:bg-sky-700 disabled:opacity-50 rounded-lg"
              >
                {sending ? 'Yuborilmoqda...' : 'Yuborish'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Balance Modal */}
      {balanceTarget && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-sm w-full p-6 shadow-xl">
            <h3 className="text-base font-semibold text-slate-900">
              Balansni o‘zgartirish · {balanceTarget.firstName}
            </h3>
            <label className="block text-xs font-medium text-slate-600 mt-3 mb-1">
              Yangi balans (so‘m)
            </label>
            <input
              type="number"
              min={0}
              value={balanceValue}
              onChange={(e) => setBalanceValue(e.target.value)}
              className="w-full px-3 py-2 text-sm font-mono tabular-nums border border-slate-200 rounded-lg"
            />
            <div className="mt-4 flex justify-end gap-2">
              <button
                onClick={() => setBalanceTarget(null)}
                className="px-4 py-2 text-xs font-medium text-slate-700 bg-slate-100 rounded-lg"
              >
                Bekor qilish
              </button>
              <button
                onClick={async () => {
                  await onUpdateUser(balanceTarget.telegramId, {
                    balance: Math.max(0, Number(balanceValue) || 0),
                  });
                  setBalanceTarget(null);
                }}
                className="px-4 py-2 text-xs font-medium text-white bg-sky-600 hover:bg-sky-700 rounded-lg"
              >
                Saqlash
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
