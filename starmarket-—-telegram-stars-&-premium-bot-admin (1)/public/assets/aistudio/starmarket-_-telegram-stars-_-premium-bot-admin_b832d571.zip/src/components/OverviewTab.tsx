import { CheckCircle2, Clock, ExternalLink, Send, XCircle } from 'lucide-react';
import type { BotRuntimeStatus, DashboardSummary, Order, ShopSettings } from '../types.ts';
import { formatDateTime, formatUptime, formatUzs, orderStatusLabel } from '../utils/format.ts';

interface OverviewTabProps {
  status: BotRuntimeStatus;
  summary: DashboardSummary;
  orders: Order[];
  settings: ShopSettings;
  onUpdateOrderStatus: (orderId: string, status: 'completed' | 'cancelled') => Promise<void>;
  onNavigateTab: (tab: 'orders' | 'products' | 'settings') => void;
  onTestAdminPing: () => Promise<void>;
  pingBusy: boolean;
}

export function OverviewTab({
  status,
  summary,
  orders,
  settings,
  onUpdateOrderStatus,
  onNavigateTab,
  onTestAdminPing,
  pingBusy,
}: OverviewTabProps) {
  const maxDailyRevenue = Math.max(1, ...summary.dailyRevenue.map((d) => d.revenue));
  const recentOrders = orders.slice(0, 6);

  return (
    <div className="space-y-6">
      {/* 4-column KPI strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500">Jami tushum</p>
          <p className="mt-2 text-2xl font-semibold text-slate-900 font-mono tabular-nums">
            {formatUzs(summary.totalRevenue)}
          </p>
          <p className="mt-1.5 text-xs text-slate-500 tabular-nums">
            {summary.completedOrdersCount} ta bajarilgan buyurtma
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500">Kutilayotgan buyurtmalar</p>
          <p className="mt-2 text-2xl font-semibold text-slate-900 font-mono tabular-nums">
            {summary.pendingOrdersCount}
          </p>
          <p className="mt-1.5 text-xs text-amber-700">
            {summary.pendingOrdersCount > 0 ? 'Chek tasdiqlash kutilmoqda' : 'Barcha buyurtmalar ko‘rib chiqilgan'}
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500">Bot foydalanuvchilari</p>
          <p className="mt-2 text-2xl font-semibold text-slate-900 font-mono tabular-nums">
            {summary.totalUsersCount}
          </p>
          <p className="mt-1.5 text-xs text-slate-500 tabular-nums">
            {summary.activeProductsCount} ta faol tarif sotuvda
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500">Mijozlar tejagan summa</p>
          <p className="mt-2 text-2xl font-semibold text-emerald-700 font-mono tabular-nums">
            {formatUzs(summary.totalSavingsForUsers)}
          </p>
          <p className="mt-1.5 text-xs text-slate-500">
            Bozor narxiga nisbatan chegirma
          </p>
        </div>
      </div>

      {/* Middle 2-column grid: 7-day Revenue Chart + Live Bot Connection */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between">
          <div className="flex items-center justify-between gap-4 mb-6">
            <div>
              <h2 className="text-base font-semibold text-slate-900">So‘nggi 7 kunlik savdo dinamikasi</h2>
              <p className="text-xs text-slate-500 mt-0.5">Tasdiqlangan buyurtmalar bo‘yicha kunlik tushum</p>
            </div>
            <button
              onClick={() => onNavigateTab('products')}
              className="text-xs font-medium text-sky-700 hover:text-sky-800 whitespace-nowrap shrink-0"
            >
              Narxlarni tahrirlash →
            </button>
          </div>

          <div className="grid grid-cols-7 gap-3 items-end h-44 pt-4 border-b border-slate-100 pb-3">
            {summary.dailyRevenue.map((day) => {
              const heightPct = day.revenue > 0 ? Math.max(10, Math.round((day.revenue / maxDailyRevenue) * 100)) : 4;
              return (
                <div key={day.date} className="flex flex-col items-center justify-end h-full gap-2 group">
                  <div className="text-[11px] font-mono tabular-nums text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                    {day.revenue > 0 ? formatUzs(day.revenue) : '0'}
                  </div>
                  <div className="w-full max-w-[40px] flex-1 flex items-end">
                    <div
                      style={{ height: `${heightPct}%` }}
                      className={`w-full rounded-t-md transition-colors ${
                        day.revenue > 0 ? 'bg-sky-600 hover:bg-sky-700' : 'bg-slate-100'
                      }`}
                      title={`${day.label}: ${formatUzs(day.revenue)} (${day.orders} ta)`}
                    />
                  </div>
                  <span className="text-xs text-slate-500 tabular-nums whitespace-nowrap">{day.label}</span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-3">
              <h2 className="text-base font-semibold text-slate-900">Telegram Bot Holati</h2>
              <span
                className={`text-xs font-medium ${
                  status.running ? 'text-emerald-700' : 'text-amber-700'
                }`}
              >
                {status.running
                  ? status.connectionMode === 'webhook'
                    ? '24/7 Webhook'
                    : '24/7 Polling'
                  : 'Ulanmoqda'}
              </span>
            </div>

            <div className="mt-5 space-y-3 text-sm divide-y divide-slate-100">
              <div className="flex items-center justify-between pt-1">
                <span className="text-slate-500">Bot manzili</span>
                {status.botUsername ? (
                  <a
                    href={`https://t.me/${status.botUsername}`}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 font-mono text-sky-700 hover:text-sky-800 font-medium"
                  >
                    @{status.botUsername}
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                ) : (
                  <span className="font-mono text-slate-700">Tekshirilmoqda...</span>
                )}
              </div>

              <div className="flex items-center justify-between pt-3">
                <span className="text-slate-500">Asosiy Admin ID</span>
                <span className="font-mono tabular-nums text-slate-900 font-medium">
                  {settings.adminIds.join(', ')}
                </span>
              </div>

              <div className="flex items-center justify-between pt-3">
                <span className="text-slate-500">Uzluksiz ishlash</span>
                <span className="font-mono tabular-nums text-slate-900">
                  {formatUptime(status.uptimeSeconds)}
                </span>
              </div>

              <div className="flex items-center justify-between pt-3">
                <span className="text-slate-500">Ulanish turi</span>
                <span className="text-slate-900 font-medium">
                  {status.connectionMode === 'webhook' ? 'Webhook (Cloud 24/7)' : 'Long Polling (Avto)'}
                </span>
              </div>

              <div className="flex items-center justify-between pt-3">
                <span className="text-slate-500">Do‘kon tartibi</span>
                <span className="text-slate-900 font-medium">
                  {settings.maintenanceMode ? 'Texnik tanaffus' : 'Ochiq (Avto-qabul)'}
                </span>
              </div>
            </div>

            {status.lastError && (
              <p className="mt-4 text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded-lg p-2.5">
                So‘nggi xatolik: {status.lastError}
              </p>
            )}
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 flex flex-col gap-2">
            <button
              onClick={onTestAdminPing}
              disabled={pingBusy}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-sky-600 hover:bg-sky-700 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <Send className="w-4 h-4" />
              {pingBusy ? 'Yuborilmoqda...' : 'Admin Telegramga test xabar yuborish'}
            </button>
          </div>
        </div>
      </div>

      {/* Recent Orders Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">So‘nggi buyurtmalar</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Bot orqali tushgan chek va buyurtmalarni tezkor tasdiqlash
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('orders')}
            className="text-xs font-medium text-sky-700 hover:text-sky-800 whitespace-nowrap shrink-0"
          >
            Barchasini ko‘rish →
          </button>
        </div>

        {recentOrders.length === 0 ? (
          <div className="px-6 py-12 text-center">
            <p className="text-sm font-medium text-slate-900">Hali buyurtmalar tushmagan</p>
            <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
              Telegramda @{status.botUsername || 'botingiz'} ga kirib /start bosing va sinov buyurtma yarating — bu yerda darhol ko‘rinadi.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-medium text-slate-500">
                  <th className="py-3 px-6">Buyurtma</th>
                  <th className="py-3 px-4">Mijoz</th>
                  <th className="py-3 px-4">Xizmat</th>
                  <th className="py-3 px-4">Qabul qiluvchi</th>
                  <th className="py-3 px-4 text-right">Summa</th>
                  <th className="py-3 px-4">Holat</th>
                  <th className="py-3 px-6 text-right">Amal</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {recentOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-6">
                      <div className="font-mono text-xs font-medium text-slate-900">{order.id}</div>
                      <div className="text-xs text-slate-500 tabular-nums">{formatDateTime(order.createdAt)}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-900">{order.firstName}</div>
                      <div className="text-xs text-slate-500 font-mono">
                        {order.username ? `@${order.username}` : `ID: ${order.userId}`}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-800">{order.productTitle}</td>
                    <td className="py-3 px-4 font-mono text-xs text-slate-700">{order.targetUsername}</td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums font-medium text-slate-900">
                      {formatUzs(order.paidAmount)}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex items-center gap-1.5 text-xs font-medium ${
                          order.status === 'completed'
                            ? 'text-emerald-700'
                            : order.status === 'cancelled'
                            ? 'text-rose-700'
                            : 'text-amber-700'
                        }`}
                      >
                        {order.status === 'completed' ? (
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        ) : order.status === 'cancelled' ? (
                          <XCircle className="w-3.5 h-3.5" />
                        ) : (
                          <Clock className="w-3.5 h-3.5" />
                        )}
                        {orderStatusLabel(order.status)}
                      </span>
                    </td>
                    <td className="py-3 px-6 text-right">
                      {order.status === 'pending_review' ? (
                        <div className="inline-flex items-center gap-2">
                          <button
                            onClick={() => onUpdateOrderStatus(order.id, 'completed')}
                            className="px-2.5 py-1 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-700 rounded-md transition-colors whitespace-nowrap shrink-0"
                          >
                            Tasdiqlash
                          </button>
                          <button
                            onClick={() => onUpdateOrderStatus(order.id, 'cancelled')}
                            className="px-2.5 py-1 text-xs font-medium text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-md transition-colors whitespace-nowrap shrink-0"
                          >
                            Rad etish
                          </button>
                        </div>
                      ) : (
                        <span className="text-xs text-slate-400">Ko‘rilgan</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
