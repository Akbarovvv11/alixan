import { useMemo, useState } from 'react';
import { CheckCircle2, Clock, Image as ImageIcon, Search, X, XCircle } from 'lucide-react';
import type { Order, OrderStatus } from '../types.ts';
import { categoryLabel, formatDateTime, formatUzs, orderStatusLabel } from '../utils/format.ts';

interface OrdersTabProps {
  orders: Order[];
  onUpdateOrderStatus: (orderId: string, status: OrderStatus, adminNote?: string) => Promise<void>;
}

export function OrdersTab({ orders, onUpdateOrderStatus }: OrdersTabProps) {
  const [filter, setFilter] = useState<'all' | OrderStatus>('all');
  const [query, setQuery] = useState('');
  const [receiptOrder, setReceiptOrder] = useState<Order | null>(null);
  const [rejectOrder, setRejectOrder] = useState<Order | null>(null);
  const [rejectReason, setRejectReason] = useState('To‘lov cheki tasdiqlanmadi yoki summa mos kelmadi');
  const [busyId, setBusyId] = useState<string | null>(null);

  const filteredOrders = useMemo(() => {
    const q = query.trim().toLowerCase();
    return orders.filter((order) => {
      if (filter !== 'all' && order.status !== filter) return false;
      if (!q) return true;
      return (
        order.id.toLowerCase().includes(q) ||
        order.productTitle.toLowerCase().includes(q) ||
        order.targetUsername.toLowerCase().includes(q) ||
        (order.username || '').toLowerCase().includes(q) ||
        order.firstName.toLowerCase().includes(q) ||
        String(order.userId).includes(q)
      );
    });
  }, [orders, filter, query]);

  const counts = useMemo(() => {
    return {
      all: orders.length,
      pending_review: orders.filter((o) => o.status === 'pending_review').length,
      completed: orders.filter((o) => o.status === 'completed').length,
      cancelled: orders.filter((o) => o.status === 'cancelled').length,
    };
  }, [orders]);

  async function handleAction(orderId: string, status: OrderStatus, note?: string) {
    setBusyId(orderId);
    try {
      await onUpdateOrderStatus(orderId, status, note);
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="space-y-4">
      {/* Filter & Search Toolbar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg overflow-x-auto">
          {(
            [
              { key: 'all', label: `Hammasi (${counts.all})` },
              { key: 'pending_review', label: `Kutilmoqda (${counts.pending_review})` },
              { key: 'completed', label: `Bajarildi (${counts.completed})` },
              { key: 'cancelled', label: `Bekor qilindi (${counts.cancelled})` },
            ] as const
          ).map((tab) => (
            <button
              key={tab.key}
              onClick={() => setFilter(tab.key)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 tabular-nums ${
                filter === tab.key
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buyurtma ID, @username..."
            className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-600"
          />
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        {filteredOrders.length === 0 ? (
          <div className="px-6 py-14 text-center">
            <p className="text-sm font-medium text-slate-900">Mos buyurtmalar topilmadi</p>
            <p className="text-xs text-slate-500 mt-1">
              Mijozlar botga to‘lov cheki yuborganida buyurtmalar bu jadvalda paydo bo‘ladi.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-medium text-slate-500">
                  <th className="py-3 px-6">Buyurtma</th>
                  <th className="py-3 px-4">Mijoz</th>
                  <th className="py-3 px-4">Xizmat / Qabul qiluvchi</th>
                  <th className="py-3 px-4 text-right">To‘lov</th>
                  <th className="py-3 px-4">Chek</th>
                  <th className="py-3 px-4">Holat</th>
                  <th className="py-3 px-6 text-right">Boshqaruv</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filteredOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3.5 px-6">
                      <div className="font-mono text-xs font-semibold text-slate-900">{order.id}</div>
                      <div className="text-xs text-slate-500 tabular-nums mt-0.5">
                        {formatDateTime(order.createdAt)}
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-medium text-slate-900">{order.firstName}</div>
                      <div className="text-xs text-slate-500 font-mono">
                        {order.username ? `@${order.username}` : `ID: ${order.userId}`}
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-medium text-slate-900">{order.productTitle}</div>
                      <div className="text-xs text-slate-500 mt-0.5">
                        {categoryLabel(order.category)} ·{' '}
                        <span className="font-mono text-slate-700">{order.targetUsername}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="font-mono tabular-nums font-medium text-slate-900">
                        {formatUzs(order.paidAmount)}
                      </div>
                      <div className="font-mono tabular-nums text-xs text-slate-400 line-through">
                        {formatUzs(order.marketPrice)}
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      {order.receiptFileId ? (
                        <button
                          onClick={() => setReceiptOrder(order)}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-sky-700 bg-sky-50 hover:bg-sky-100 rounded-md transition-colors whitespace-nowrap shrink-0"
                        >
                          <ImageIcon className="w-3.5 h-3.5" />
                          Chekni ko‘rish
                        </button>
                      ) : (
                        <span className="text-xs text-slate-400">Rasm yo‘q</span>
                      )}
                    </td>
                    <td className="py-3.5 px-4">
                      <div
                        className={`inline-flex items-center gap-1.5 text-xs font-medium ${
                          order.status === 'completed'
                            ? 'text-emerald-700'
                            : order.status === 'cancelled'
                            ? 'text-rose-700'
                            : 'text-amber-700'
                        }`}
                      >
                        {order.status === 'completed' ? (
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        ) : order.status === 'cancelled' ? (
                          <XCircle className="w-3.5 h-3.5" />
                        ) : (
                          <Clock className="w-3.5 h-3.5" />
                        )}
                        {orderStatusLabel(order.status)}
                      </div>
                      {order.adminNote && (
                        <div className="text-xs text-slate-500 mt-0.5 max-w-[180px] truncate" title={order.adminNote}>
                          {order.adminNote}
                        </div>
                      )}
                    </td>
                    <td className="py-3.5 px-6 text-right">
                      {order.status === 'pending_review' ? (
                        <div className="inline-flex items-center gap-2">
                          <button
                            disabled={busyId === order.id}
                            onClick={() => handleAction(order.id, 'completed', 'Admin tomonidan bajarildi')}
                            className="px-3 py-1.5 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 rounded-md transition-colors whitespace-nowrap shrink-0"
                          >
                            Tasdiqlash
                          </button>
                          <button
                            disabled={busyId === order.id}
                            onClick={() => setRejectOrder(order)}
                            className="px-3 py-1.5 text-xs font-medium text-rose-700 bg-rose-50 hover:bg-rose-100 disabled:opacity-50 rounded-md transition-colors whitespace-nowrap shrink-0"
                          >
                            Rad etish
                          </button>
                        </div>
                      ) : (
                        <button
                          disabled={busyId === order.id}
                          onClick={() => handleAction(order.id, 'pending_review')}
                          className="text-xs font-medium text-slate-500 hover:text-slate-900 whitespace-nowrap shrink-0"
                        >
                          Qayta ko‘rish
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Receipt Preview Modal */}
      {receiptOrder && receiptOrder.receiptFileId && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-lg w-full overflow-hidden shadow-xl">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold text-slate-900">
                  To‘lov cheki · {receiptOrder.id}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {receiptOrder.productTitle} — {formatUzs(receiptOrder.paidAmount)}
                </p>
              </div>
              <button
                onClick={() => setReceiptOrder(null)}
                className="p-1.5 text-slate-500 hover:text-slate-900 rounded-lg hover:bg-slate-100"
                aria-label="Yopish"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 bg-slate-50 flex items-center justify-center max-h-[65vh] overflow-auto">
              <img
                src={`/api/receipt/${encodeURIComponent(receiptOrder.receiptFileId)}`}
                alt={`Buyurtma ${receiptOrder.id} cheki`}
                referrerPolicy="no-referrer"
                className="max-h-[55vh] rounded-lg border border-slate-200 object-contain"
              />
            </div>
            <div className="px-5 py-4 border-t border-slate-200 flex items-center justify-end gap-2">
              {receiptOrder.status === 'pending_review' && (
                <>
                  <button
                    onClick={async () => {
                      const target = receiptOrder;
                      setReceiptOrder(null);
                      setRejectOrder(target);
                    }}
                    className="px-4 py-2 text-xs font-medium text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg"
                  >
                    Rad etish
                  </button>
                  <button
                    onClick={async () => {
                      const id = receiptOrder.id;
                      setReceiptOrder(null);
                      await handleAction(id, 'completed', 'Admin tomonidan tasdiqlandi');
                    }}
                    className="px-4 py-2 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg"
                  >
                    Tasdiqlash va mijozga xabar berish
                  </button>
                </>
              )}
              <button
                onClick={() => setReceiptOrder(null)}
                className="px-4 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
              >
                Yopish
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reject Reason Modal */}
      {rejectOrder && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6 shadow-xl">
            <h3 className="text-base font-semibold text-slate-900">
              Buyurtmani bekor qilish ({rejectOrder.id})
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Sabab mijozga Telegram bot orqali yuboriladi.
            </p>
            <textarea
              rows={3}
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              className="mt-4 w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-600"
            />
            <div className="mt-4 flex items-center justify-end gap-2">
              <button
                onClick={() => setRejectOrder(null)}
                className="px-4 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
              >
                Ortga
              </button>
              <button
                onClick={async () => {
                  const id = rejectOrder.id;
                  const reason = rejectReason.trim();
                  setRejectOrder(null);
                  await handleAction(id, 'cancelled', reason);
                }}
                className="px-4 py-2 text-xs font-medium text-white bg-rose-600 hover:bg-rose-700 rounded-lg"
              >
                Bekor qilishni tasdiqlash
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
